import { createContext, useCallback, useContext, useMemo, useState, ReactNode } from 'react'
import { SEMUA_PENGGUNA, SANDI_DEMO, getPenggunaById, type Pengguna } from '../data/mockData'

const KUNCI_SESI = 'simonlomba.sesi'

interface Sesi { user: Pengguna; token: string }

function bacaSesi(): Sesi | null {
  try {
    const raw = localStorage.getItem(KUNCI_SESI)
    if (!raw) return null
    const sesi = JSON.parse(raw)
    return sesi?.user?.id ? sesi : null
  } catch { return null }
}
function simpanSesi(sesi: Sesi) {
  try { localStorage.setItem(KUNCI_SESI, JSON.stringify(sesi)) } catch {}
}
function hapusSesi() {
  try { localStorage.removeItem(KUNCI_SESI) } catch {}
}

export function berandaRole(role?: string | null) {
  return role === 'dosen' || role === 'admin' ? '/monitoring' : '/'
}

const KUNCI_AKUN = 'simonlomba.akun'
export const KODE_ADMIN = 'PRODI2026'

interface AkunTerdaftar { user: Pengguna; password: string }

function bacaAkun(): AkunTerdaftar[] {
  try {
    const raw = localStorage.getItem(KUNCI_AKUN)
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr : []
  } catch { return [] }
}
function simpanAkun(akun: AkunTerdaftar[]) {
  try { localStorage.setItem(KUNCI_AKUN, JSON.stringify(akun)) } catch {}
}

export interface DataDaftar {
  nama: string
  email: string
  password: string
  role: Pengguna['role']
  prodi: string
  nim?: string
  angkatan?: number
  kodeAdmin?: string
}

export function emailTerpakai(email: string) {
  const e = email.trim().toLowerCase()
  return SEMUA_PENGGUNA.some(u => u.email.toLowerCase() === e) || bacaAkun().some(a => a.user.email.toLowerCase() === e)
}
export function nimTerpakai(nim: string) {
  return SEMUA_PENGGUNA.some(u => u.nim === nim) || bacaAkun().some(a => a.user.nim === nim)
}

interface AuthCtx {
  user: Pengguna | null
  sudahMasuk: boolean
  role: string | null
  beranda: string
  memproses: boolean
  masuk(cred: { email: string; password: string }): Promise<Pengguna>
  masukCepat(id: string): Promise<Pengguna>
  daftar(data: DataDaftar): Promise<Pengguna>
  keluar(): void
}

const AuthContext = createContext<AuthCtx | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [sesi, setSesi] = useState<Sesi | null>(() => bacaSesi())
  const [memproses, setMemproses] = useState(false)

  const masuk = useCallback(async ({ email, password }: { email: string; password: string }) => {
    setMemproses(true)
    await new Promise(r => setTimeout(r, 800))
    setMemproses(false)
    const e = email.trim().toLowerCase()
    const baru = bacaAkun().find(a => a.user.email.toLowerCase() === e)
    const demo = SEMUA_PENGGUNA.find(u => u.email.toLowerCase() === e)
    const user = baru && baru.password === password ? baru.user : demo && password === SANDI_DEMO ? demo : null
    if (!user) throw new Error('Email atau kata sandi salah.')
    const sesiBaru: Sesi = { user, token: `tok-${user.id}` }
    simpanSesi(sesiBaru)
    setSesi(sesiBaru)
    return user
  }, [])

  const masukCepat = useCallback(async (id: string) => {
    const user = getPenggunaById(id)
    if (!user) throw new Error('Akun demo tidak ditemukan.')
    return masuk({ email: user.email, password: SANDI_DEMO })
  }, [masuk])

  const daftar = useCallback(async (d: DataDaftar) => {
    setMemproses(true)
    await new Promise(r => setTimeout(r, 900))
    setMemproses(false)
    if (emailTerpakai(d.email)) throw new Error('Email ini sudah terdaftar. Silakan masuk.')
    if (d.role === 'mahasiswa' && d.nim && nimTerpakai(d.nim)) throw new Error('NIM ini sudah terdaftar.')
    if (d.role === 'admin' && d.kodeAdmin !== KODE_ADMIN) throw new Error('Kode verifikasi Admin Prodi tidak valid.')
    const user: Pengguna = {
      id: `usr-${Date.now()}`,
      nama: d.nama.trim(),
      email: d.email.trim().toLowerCase(),
      role: d.role,
      prodi: d.prodi,
      ...(d.role === 'mahasiswa' ? { nim: d.nim, angkatan: d.angkatan } : {}),
    }
    simpanAkun([...bacaAkun(), { user, password: d.password }])
    const sesiBaru: Sesi = { user, token: `tok-${user.id}` }
    simpanSesi(sesiBaru)
    setSesi(sesiBaru)
    return user
  }, [])

  const keluar = useCallback(() => { hapusSesi(); setSesi(null) }, [])

  const nilai = useMemo<AuthCtx>(() => ({
    user: sesi?.user ?? null,
    sudahMasuk: Boolean(sesi?.user),
    role: sesi?.user?.role ?? null,
    beranda: berandaRole(sesi?.user?.role),
    memproses,
    masuk,
    masukCepat,
    daftar,
    keluar,
  }), [sesi, memproses, masuk, masukCepat, daftar, keluar])

  return <AuthContext.Provider value={nilai}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth harus dipakai di dalam AuthProvider')
  return ctx
}
