import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const STEPS = ['Detail Lomba', 'Anggota Tim', 'Bukti & Poster', 'Tinjauan']

const BIDANG_OPTIONS = ['Pemrograman', 'Algoritma', 'Desain', 'Inovasi Teknologi', 'Data Science', 'Bisnis', 'Robotika', 'Lainnya']
const TINGKAT_OPTIONS = ['Kampus', 'Regional', 'Nasional', 'Internasional']

interface FormData {
  nama: string; penyelenggara: string; bidang: string; tingkat: string
  jenis: string; tanggalMulai: string; tanggalSelesai: string; deskripsi: string
  anggota: { nama: string; nim: string; peran: string }[]
}

export default function PendaftaranLomba() {
  const navigate = useNavigate()
  const [step, setStep] = useState(0)
  const [submitting, setSubmitting] = useState(false)
  const [form, setForm] = useState<FormData>({
    nama: '', penyelenggara: '', bidang: '', tingkat: '', jenis: 'tim',
    tanggalMulai: '', tanggalSelesai: '', deskripsi: '',
    anggota: [{ nama: '', nim: '', peran: 'Ketua' }],
  })

  const update = (key: keyof FormData, val: unknown) => setForm(f => ({ ...f, [key]: val }))

  const addAnggota = () => update('anggota', [...form.anggota, { nama: '', nim: '', peran: 'Anggota' }])
  const removeAnggota = (i: number) => update('anggota', form.anggota.filter((_, idx) => idx !== i))
  const updateAnggota = (i: number, key: string, val: string) =>
    update('anggota', form.anggota.map((a, idx) => idx === i ? { ...a, [key]: val } : a))

  const handleSubmit = async () => {
    setSubmitting(true)
    await new Promise(r => setTimeout(r, 1000))
    navigate('/lomba-saya')
  }

  const inputCls = 'w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 focus:border-[#254feb] bg-white'

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Daftar Lomba Baru</h1>
        <p className="text-sm text-slate-500 mt-0.5">Isi informasi lomba yang ingin didaftarkan.</p>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-0">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-colors ${i < step ? 'bg-[#254feb] border-[#254feb] text-white' : i === step ? 'border-[#254feb] text-[#254feb] bg-white' : 'border-slate-200 text-slate-400 bg-white'}`}>
                {i < step ? '✓' : i + 1}
              </div>
              <span className={`text-xs mt-1 font-medium ${i === step ? 'text-[#254feb]' : 'text-slate-400'} hidden sm:block`}>{s}</span>
            </div>
            {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 mx-2 ${i < step ? 'bg-[#254feb]' : 'bg-slate-200'}`} />}
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        {step === 0 && (
          <div className="space-y-4">
            <h2 className="font-extrabold text-slate-900 text-lg">{STEPS[0]}</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="text-sm font-medium text-slate-700 block mb-1.5">Nama Lomba <span className="text-red-500">*</span></label>
                <input className={inputCls} value={form.nama} onChange={e => update('nama', e.target.value)} placeholder="Contoh: Gemastik XVII 2024" />
              </div>
              <div className="sm:col-span-2">
                <label className="text-sm font-medium text-slate-700 block mb-1.5">Penyelenggara <span className="text-red-500">*</span></label>
                <input className={inputCls} value={form.penyelenggara} onChange={e => update('penyelenggara', e.target.value)} placeholder="Contoh: Kemendikbudristek" />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 block mb-1.5">Bidang <span className="text-red-500">*</span></label>
                <select className={inputCls} value={form.bidang} onChange={e => update('bidang', e.target.value)}>
                  <option value="">Pilih bidang</option>
                  {BIDANG_OPTIONS.map(b => <option key={b} value={b}>{b}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 block mb-1.5">Tingkat <span className="text-red-500">*</span></label>
                <select className={inputCls} value={form.tingkat} onChange={e => update('tingkat', e.target.value)}>
                  <option value="">Pilih tingkat</option>
                  {TINGKAT_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 block mb-1.5">Jenis Keikutsertaan</label>
                <div className="flex gap-4 mt-2">
                  {['tim', 'individu'].map(j => (
                    <label key={j} className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="jenis" value={j} checked={form.jenis === j} onChange={e => update('jenis', e.target.value)} className="text-[#254feb]" />
                      <span className="text-sm capitalize text-slate-700">{j}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 block mb-1.5">Tanggal Mulai</label>
                <input type="date" className={inputCls} value={form.tanggalMulai} onChange={e => update('tanggalMulai', e.target.value)} />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700 block mb-1.5">Tanggal Selesai</label>
                <input type="date" className={inputCls} value={form.tanggalSelesai} onChange={e => update('tanggalSelesai', e.target.value)} />
              </div>
              <div className="sm:col-span-2">
                <label className="text-sm font-medium text-slate-700 block mb-1.5">Deskripsi</label>
                <textarea className={inputCls} rows={3} value={form.deskripsi} onChange={e => update('deskripsi', e.target.value)} placeholder="Deskripsi singkat tentang lomba ini..." />
              </div>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-extrabold text-slate-900 text-lg">{STEPS[1]}</h2>
              {form.jenis === 'tim' && (
                <button onClick={addAnggota} className="text-sm text-[#254feb] font-semibold hover:underline">+ Tambah Anggota</button>
              )}
            </div>
            {form.jenis === 'individu' ? (
              <p className="text-sm text-slate-500 bg-slate-50 rounded-lg p-4">Keikutsertaan individu — tidak perlu menambah anggota tim.</p>
            ) : (
              <div className="space-y-3">
                {form.anggota.map((a, i) => (
                  <div key={i} className="bg-slate-50 rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-slate-700">Anggota {i + 1}</span>
                      {i > 0 && <button onClick={() => removeAnggota(i)} className="text-xs text-red-500 hover:underline">Hapus</button>}
                    </div>
                    <div className="grid sm:grid-cols-3 gap-3">
                      <div>
                        <label className="text-xs font-medium text-slate-600 block mb-1">Nama</label>
                        <input className={inputCls} value={a.nama} onChange={e => updateAnggota(i, 'nama', e.target.value)} placeholder="Nama lengkap" />
                      </div>
                      <div>
                        <label className="text-xs font-medium text-slate-600 block mb-1">NIM</label>
                        <input className={inputCls} value={a.nim} onChange={e => updateAnggota(i, 'nim', e.target.value)} placeholder="NIM" />
                      </div>
                      <div>
                        <label className="text-xs font-medium text-slate-600 block mb-1">Peran</label>
                        <select className={inputCls} value={a.peran} onChange={e => updateAnggota(i, 'peran', e.target.value)}>
                          <option>Ketua</option>
                          <option>Anggota</option>
                        </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="font-extrabold text-slate-900 text-lg">{STEPS[2]}</h2>
            {[
              { label: 'Bukti Pendaftaran', desc: 'Upload file PDF atau gambar bukti pendaftaran', required: true },
              { label: 'Bukti Pembayaran', desc: 'Upload jika pendaftaran berbayar', required: false },
              { label: 'Poster Lomba', desc: 'Upload poster atau flyer lomba (PNG/JPG)', required: false },
            ].map(f => (
              <div key={f.label}>
                <label className="text-sm font-medium text-slate-700 block mb-1">{f.label} {f.required && <span className="text-red-500">*</span>}</label>
                <p className="text-xs text-slate-400 mb-1.5">{f.desc}</p>
                <div className="border-2 border-dashed border-slate-200 rounded-lg p-6 text-center hover:border-[#254feb]/40 transition-colors cursor-pointer">
                  <p className="text-sm text-slate-400">📎 Klik untuk pilih file atau seret ke sini</p>
                  <p className="text-xs text-slate-300 mt-1">PDF, JPG, PNG — maks. 5 MB</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h2 className="font-extrabold text-slate-900 text-lg">{STEPS[3]}</h2>
            <div className="space-y-3">
              {[
                ['Nama Lomba', form.nama || '-'],
                ['Penyelenggara', form.penyelenggara || '-'],
                ['Bidang', form.bidang || '-'],
                ['Tingkat', form.tingkat || '-'],
                ['Jenis', form.jenis],
                ['Tanggal Mulai', form.tanggalMulai || '-'],
                ['Tanggal Selesai', form.tanggalSelesai || '-'],
                ['Jumlah Anggota', form.jenis === 'tim' ? String(form.anggota.length) : 'Individu'],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between py-2 border-b border-slate-50 text-sm">
                  <span className="text-slate-500">{k}</span>
                  <span className="font-medium text-slate-900 capitalize">{v}</span>
                </div>
              ))}
            </div>
            {form.deskripsi && (
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-xs font-medium text-slate-500 mb-1">Deskripsi</p>
                <p className="text-sm text-slate-700">{form.deskripsi}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Navigation */}
      <div className="flex justify-between">
        <button
          onClick={() => step > 0 ? setStep(s => s - 1) : navigate('/lomba-saya')}
          className="px-4 py-2 text-sm font-medium text-slate-600 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
        >
          {step > 0 ? '← Sebelumnya' : 'Batal'}
        </button>
        {step < STEPS.length - 1 ? (
          <button onClick={() => setStep(s => s + 1)} className="px-5 py-2 text-sm font-semibold bg-[#254feb] hover:bg-[#1d3fd4] text-white rounded-lg transition-colors">
            Selanjutnya →
          </button>
        ) : (
          <button
            onClick={handleSubmit} disabled={submitting}
            className="px-5 py-2 text-sm font-semibold bg-[#254feb] hover:bg-[#1d3fd4] disabled:opacity-70 text-white rounded-lg transition-colors flex items-center gap-2"
          >
            {submitting && <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4l3-3-3-3v4a8 8 0 00-8 8h4z" /></svg>}
            {submitting ? 'Menyimpan...' : '✓ Simpan Pendaftaran'}
          </button>
        )}
      </div>
    </div>
  )
}
