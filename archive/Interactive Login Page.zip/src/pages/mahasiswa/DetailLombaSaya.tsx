import { useState } from 'react'
import { useParams, Link, Navigate } from 'react-router-dom'
import { getLombaById, STATUS_LABELS, CAPAIAN_LABELS, namaPengguna } from '../../data/mockData'

const statusColors: Record<string, string> = {
  terdaftar: 'bg-blue-50 text-blue-700 border border-blue-200',
  berlangsung: 'bg-amber-50 text-amber-700 border border-amber-200',
  selesai: 'bg-green-50 text-green-700 border border-green-200',
}

const capaianColors: Record<string, string> = {
  juara_1: 'bg-yellow-50 text-yellow-700 border border-yellow-300',
  juara_2: 'bg-slate-50 text-slate-600 border border-slate-200',
  juara_3: 'bg-orange-50 text-orange-600 border border-orange-200',
  harapan: 'bg-purple-50 text-purple-700 border border-purple-200',
  finalis: 'bg-indigo-50 text-indigo-600 border border-indigo-200',
  peserta: 'bg-slate-50 text-slate-500 border border-slate-200',
}

const TABS = ['Informasi', 'Tim', 'Dokumen', 'Timeline', 'Hasil']

export default function DetailLombaSaya() {
  const { id } = useParams()
  const lomba = getLombaById(id ?? '')
  const [tab, setTab] = useState(0)

  if (!lomba) return <Navigate to="/lomba-saya" replace />

  const progressTahapan = Math.round((lomba.tahapan.filter(t => t.selesai).length / Math.max(lomba.tahapan.length, 1)) * 100)

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <Link to="/lomba-saya" className="hover:text-[#254feb]">Lomba Saya</Link>
        <span>›</span>
        <span className="text-slate-900 font-medium">{lomba.nama}</span>
      </div>

      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${statusColors[lomba.status]}`}>
                {STATUS_LABELS[lomba.status]}
              </span>
              {lomba.capaian && (
                <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${capaianColors[lomba.capaian]}`}>
                  🏅 {CAPAIAN_LABELS[lomba.capaian]}
                </span>
              )}
              <span className="text-xs text-slate-400 border border-slate-200 rounded-full px-2.5 py-0.5">{lomba.tingkat}</span>
            </div>
            <h1 className="text-xl font-extrabold text-slate-900">{lomba.nama}</h1>
            <p className="text-slate-500 text-sm mt-0.5">{lomba.penyelenggara} · {lomba.bidang}</p>
          </div>
          <div className="text-right shrink-0">
            <p className="text-xs text-slate-400">Dosen Pembimbing</p>
            <p className="text-sm font-semibold text-slate-700">{namaPengguna(lomba.dosenId)}</p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-4">
          <div className="flex justify-between text-xs text-slate-500 mb-1">
            <span>Progress Tahapan</span>
            <span>{progressTahapan}%</span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-[#254feb] rounded-full transition-all" style={{ width: `${progressTahapan}%` }} />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-0.5 bg-slate-100 rounded-xl p-1 w-full overflow-x-auto">
        {TABS.map((t, i) => (
          <button key={t} onClick={() => setTab(i)}
            className={`flex-1 px-3 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-colors cursor-pointer ${tab === i ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
            {t}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        {tab === 0 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-slate-900">Informasi Lomba</h3>
            <div className="grid sm:grid-cols-2 gap-3">
              {[
                ['Nama Lomba', lomba.nama],
                ['Penyelenggara', lomba.penyelenggara],
                ['Bidang', lomba.bidang],
                ['Tingkat', lomba.tingkat],
                ['Jenis', lomba.jenis],
                ['Tanggal Mulai', new Date(lomba.tanggalMulai).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })],
                ['Tanggal Selesai', new Date(lomba.tanggalSelesai).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })],
                ['Status', STATUS_LABELS[lomba.status]],
              ].map(([k, v]) => (
                <div key={k} className="bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-400 mb-0.5">{k}</p>
                  <p className="text-sm font-semibold text-slate-900 capitalize">{v}</p>
                </div>
              ))}
              {lomba.deskripsi && (
                <div className="sm:col-span-2 bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-400 mb-0.5">Deskripsi</p>
                  <p className="text-sm text-slate-700">{lomba.deskripsi}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 1 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-slate-900">Anggota Tim</h3>
            {lomba.anggota.length === 0 ? (
              <p className="text-slate-400 text-sm">Belum ada anggota tim.</p>
            ) : (
              <div className="space-y-2">
                {lomba.anggota.map(a => (
                  <div key={a.id} className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                    <div className="h-10 w-10 rounded-full bg-[#254feb]/10 text-[#254feb] flex items-center justify-center font-bold text-sm shrink-0">
                      {a.nama.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-900 text-sm">{a.nama}</p>
                      <p className="text-xs text-slate-500">{a.nim}</p>
                    </div>
                    <span className={`ml-auto text-xs font-semibold px-2.5 py-0.5 rounded-full ${a.peran === 'Ketua' ? 'bg-[#254feb]/10 text-[#254feb]' : 'bg-slate-100 text-slate-600'}`}>
                      {a.peran}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 2 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-slate-900">Dokumen & Berkas</h3>
              <button className="text-sm text-[#254feb] font-semibold hover:underline">+ Unggah Berkas</button>
            </div>
            {lomba.berkas.length === 0 ? (
              <div className="border-2 border-dashed border-slate-200 rounded-xl p-10 text-center">
                <p className="text-slate-400 text-sm">Belum ada berkas yang diunggah</p>
                <button className="mt-3 text-sm text-[#254feb] font-semibold hover:underline">Unggah Berkas Pertama</button>
              </div>
            ) : (
              <div className="space-y-2">
                {lomba.berkas.map(b => (
                  <div key={b.id} className="flex items-center gap-4 p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                    <div className="h-10 w-10 bg-[#254feb]/8 rounded-lg flex items-center justify-center text-[#254feb] shrink-0">📄</div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 truncate">{b.nama}</p>
                      <p className="text-xs text-slate-400">{b.jenis} · {b.ukuran}</p>
                    </div>
                    <button className="ml-auto text-xs text-[#254feb] font-medium hover:underline shrink-0">Unduh</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 3 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-slate-900">Timeline Tahapan</h3>
            <div className="relative pl-6">
              {lomba.tahapan.map((t, i) => (
                <div key={t.id} className="relative flex gap-4 pb-6 last:pb-0">
                  <div className="absolute left-[-24px] top-0 flex flex-col items-center">
                    <div className={`h-6 w-6 rounded-full border-2 flex items-center justify-center text-xs font-bold ${t.selesai ? 'bg-green-500 border-green-500 text-white' : 'bg-white border-slate-300 text-slate-400'}`}>
                      {t.selesai ? '✓' : i + 1}
                    </div>
                    {i < lomba.tahapan.length - 1 && <div className={`w-0.5 flex-1 mt-1 ${t.selesai ? 'bg-green-300' : 'bg-slate-200'}`} style={{ minHeight: '32px' }} />}
                  </div>
                  <div className={`flex-1 p-3 rounded-lg border ${t.selesai ? 'bg-green-50 border-green-200' : 'bg-slate-50 border-slate-200'}`}>
                    <div className="flex items-center justify-between">
                      <p className="font-semibold text-slate-900 text-sm">{t.label}</p>
                      <span className={`text-xs font-semibold ${t.selesai ? 'text-green-600' : 'text-slate-400'}`}>{t.selesai ? 'Selesai' : 'Menunggu'}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{new Date(t.tanggal).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 4 && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-slate-900">Hasil Lomba</h3>
            {lomba.capaian ? (
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 text-center">
                <div className="text-4xl mb-3">{lomba.capaian.startsWith('juara') ? '🏆' : lomba.capaian === 'finalis' ? '🥈' : '📋'}</div>
                <p className="font-extrabold text-2xl text-slate-900">{CAPAIAN_LABELS[lomba.capaian]}</p>
                <p className="text-slate-500 text-sm mt-1">{lomba.nama}</p>
                <p className="text-slate-400 text-sm mt-0.5">{lomba.penyelenggara}</p>
              </div>
            ) : lomba.status !== 'selesai' ? (
              <div className="text-center py-8 text-slate-400">
                <p className="text-2xl mb-2">⏳</p>
                <p className="text-sm">Lomba masih berlangsung. Hasil akan dilaporkan setelah selesai.</p>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-slate-500">Lomba telah selesai. Laporkan hasil capaian di bawah.</p>
                <select className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30">
                  <option value="">Pilih capaian</option>
                  {Object.entries(CAPAIAN_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
                <textarea className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30" rows={3} placeholder="Catatan tambahan (opsional)..." />
                <button className="px-5 py-2 bg-[#254feb] text-white font-semibold text-sm rounded-lg hover:bg-[#1d3fd4] transition-colors">Simpan Hasil</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
