import { useAuth } from '../../auth/AuthContext'
import { useNavigate } from 'react-router-dom'

const ROLE_LABELS: Record<string, string> = {
  mahasiswa: 'Mahasiswa', dosen: 'Dosen', admin: 'Admin Prodi',
}

export default function Profil() {
  const { user, role, keluar } = useAuth()
  const navigate = useNavigate()

  const handleKeluar = () => { keluar(); navigate('/login') }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Profil</h1>
          <p className="text-sm text-slate-500 mt-0.5">Identitas yang dipakai pada setiap pendaftaran lomba.</p>
        </div>
        <button
          onClick={handleKeluar}
          className="flex items-center gap-2 text-sm font-medium text-slate-600 border border-slate-200 px-3 py-2 rounded-lg hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors"
        >
          ↩ Keluar
        </button>
      </div>

      {/* Avatar + name card */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <div className="flex items-center gap-5 mb-6">
          <div className="h-16 w-16 rounded-2xl bg-[#254feb]/10 text-[#254feb] flex items-center justify-center text-2xl font-extrabold shrink-0">
            {user?.nama?.charAt(0) ?? '?'}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-extrabold text-slate-900">{user?.nama}</h2>
              <span className="text-xs font-semibold bg-[#254feb]/10 text-[#254feb] px-2.5 py-0.5 rounded-full">
                {ROLE_LABELS[role ?? ''] ?? role}
              </span>
            </div>
            {user?.nim && <p className="text-slate-500 text-sm mt-0.5">{user.nim}</p>}
          </div>
        </div>

        <dl className="divide-y divide-slate-100">
          {[
            ['Email', user?.email],
            ...(user?.nim ? [['NIM', user.nim]] : []),
            ['Program Studi', user?.prodi],
            ...(user?.angkatan ? [['Angkatan', String(user.angkatan)]] : []),
            ['Role', ROLE_LABELS[role ?? ''] ?? role],
          ].map(([k, v]) => (
            <div key={k} className="flex flex-col sm:flex-row sm:items-center gap-0.5 sm:gap-4 py-3">
              <dt className="w-40 shrink-0 text-sm text-slate-500">{k}</dt>
              <dd className="text-sm font-medium text-slate-900">{v ?? '-'}</dd>
            </div>
          ))}
        </dl>
      </div>

      {/* Notice */}
      <div className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4">
        <span className="text-slate-400 mt-0.5">🔒</span>
        <p className="text-sm text-slate-600">
          Data profil berasal dari akun kampus dan tidak bisa diubah dari halaman ini.
        </p>
      </div>
    </div>
  )
}
