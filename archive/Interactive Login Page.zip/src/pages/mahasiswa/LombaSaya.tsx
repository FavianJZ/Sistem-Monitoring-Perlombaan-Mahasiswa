import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useAuth } from '../../auth/AuthContext'
import { getLombaByMahasiswa, STATUS_LABELS, CAPAIAN_LABELS, type StatusLomba } from '../../data/mockData'

const statusColors: Record<string, string> = {
  terdaftar: 'bg-blue-50 text-blue-700 border border-blue-200',
  berlangsung: 'bg-amber-50 text-amber-700 border border-amber-200',
  selesai: 'bg-green-50 text-green-700 border border-green-200',
}

const capaianColors: Record<string, string> = {
  juara_1: 'bg-yellow-50 text-yellow-700 border border-yellow-200',
  juara_2: 'bg-slate-50 text-slate-600 border border-slate-200',
  juara_3: 'bg-orange-50 text-orange-600 border border-orange-200',
  harapan: 'bg-purple-50 text-purple-700 border border-purple-200',
  finalis: 'bg-indigo-50 text-indigo-600 border border-indigo-200',
  peserta: 'bg-slate-50 text-slate-500 border border-slate-200',
}

export default function LombaSaya() {
  const { user } = useAuth()
  const [searchParams] = useSearchParams()
  const allLomba = getLombaByMahasiswa(user?.id ?? '')

  const [query, setQuery] = useState('')
  const [status, setStatus] = useState<StatusLomba | ''>(
    (searchParams.get('status') as StatusLomba) ?? ''
  )

  const filtered = allLomba.filter(l => {
    const matchQ = l.nama.toLowerCase().includes(query.toLowerCase()) || l.penyelenggara.toLowerCase().includes(query.toLowerCase())
    const matchS = status ? l.status === status : true
    return matchQ && matchS
  })

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Lomba Saya</h1>
          <p className="text-sm text-slate-500 mt-0.5">{allLomba.length} lomba tercatat</p>
        </div>
        <Link to="/lomba-saya/baru" className="inline-flex items-center gap-2 bg-[#254feb] hover:bg-[#1d3fd4] text-white font-semibold text-sm px-4 py-2 rounded-lg transition-colors shadow-sm">
          + Daftar Lomba Baru
        </Link>
      </div>

      {/* Filter bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          value={query} onChange={e => setQuery(e.target.value)}
          placeholder="Cari nama lomba atau penyelenggara..."
          className="flex-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 focus:border-[#254feb] bg-white"
        />
        <select
          value={status} onChange={e => setStatus(e.target.value as StatusLomba | '')}
          className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 focus:border-[#254feb] bg-white"
        >
          <option value="">Semua Status</option>
          <option value="terdaftar">Terdaftar</option>
          <option value="berlangsung">Berlangsung</option>
          <option value="selesai">Selesai</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                {['Nama Lomba', 'Bidang', 'Tingkat', 'Jenis', 'Status', 'Capaian', ''].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map(l => (
                <tr key={l.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3.5">
                    <p className="font-semibold text-slate-900">{l.nama}</p>
                    <p className="text-xs text-slate-400">{l.penyelenggara}</p>
                  </td>
                  <td className="px-5 py-3.5 text-slate-600">{l.bidang}</td>
                  <td className="px-5 py-3.5 text-slate-600">{l.tingkat}</td>
                  <td className="px-5 py-3.5 text-slate-600 capitalize">{l.jenis}</td>
                  <td className="px-5 py-3.5">
                    <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${statusColors[l.status]}`}>
                      {STATUS_LABELS[l.status]}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    {l.capaian ? (
                      <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${capaianColors[l.capaian]}`}>
                        {CAPAIAN_LABELS[l.capaian]}
                      </span>
                    ) : <span className="text-slate-300 text-xs">-</span>}
                  </td>
                  <td className="px-5 py-3.5">
                    <Link to={`/lomba-saya/${l.id}`} className="text-[#254feb] font-medium text-xs hover:underline">Detail →</Link>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="py-12 text-center text-slate-400 text-sm">Tidak ada lomba ditemukan</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
