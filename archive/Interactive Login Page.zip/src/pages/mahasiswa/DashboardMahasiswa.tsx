import { Link } from 'react-router-dom'
import { useAuth } from '../../auth/AuthContext'
import { getLombaByMahasiswa, STATUS_LABELS, CAPAIAN_LABELS } from '../../data/mockData'

const statusColors: Record<string, string> = {
  terdaftar: 'bg-blue-50 text-blue-700 border border-blue-200',
  berlangsung: 'bg-amber-50 text-amber-700 border border-amber-200',
  selesai: 'bg-green-50 text-green-700 border border-green-200',
}

const capaianColors: Record<string, string> = {
  juara_1: 'bg-yellow-50 text-yellow-700 border border-yellow-200',
  juara_2: 'bg-slate-50 text-slate-600 border border-slate-200',
  juara_3: 'bg-orange-50 text-orange-600 border border-orange-200',
  harapan: 'bg-purple-50 text-purple-600 border border-purple-200',
  finalis: 'bg-indigo-50 text-indigo-600 border border-indigo-200',
  peserta: 'bg-slate-50 text-slate-500 border border-slate-200',
}

export default function DashboardMahasiswa() {
  const { user } = useAuth()
  const lomba = getLombaByMahasiswa(user?.id ?? '')

  const stats = {
    total: lomba.length,
    berlangsung: lomba.filter(l => l.status === 'berlangsung').length,
    selesai: lomba.filter(l => l.status === 'selesai').length,
    terdaftar: lomba.filter(l => l.status === 'terdaftar').length,
  }

  const upcoming = lomba
    .flatMap(l => l.tahapan.filter(t => !t.selesai).map(t => ({ ...t, lombaId: l.id, lombaNama: l.nama })))
    .sort((a, b) => a.tanggal.localeCompare(b.tanggal))
    .slice(0, 5)

  const berkasTidakLengkap = lomba.filter(l => l.berkas.length === 0)

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Dashboard</h1>
          <p className="text-sm text-slate-500 mt-0.5">Halo, {user?.nama?.split(' ')[0]}! Berikut ringkasan aktivitas lombamu.</p>
        </div>
        <Link to="/lomba-saya/baru" className="inline-flex items-center gap-2 bg-[#254feb] hover:bg-[#1d3fd4] text-white font-semibold text-sm px-4 py-2 rounded-lg transition-colors shadow-sm">
          + Daftar Lomba Baru
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Lomba', value: stats.total, color: 'text-[#254feb]', bg: 'bg-[#254feb]/8', to: '/lomba-saya' },
          { label: 'Berlangsung', value: stats.berlangsung, color: 'text-amber-600', bg: 'bg-amber-50', to: '/lomba-saya?status=berlangsung' },
          { label: 'Terdaftar', value: stats.terdaftar, color: 'text-sky-600', bg: 'bg-sky-50', to: '/lomba-saya?status=terdaftar' },
          { label: 'Selesai', value: stats.selesai, color: 'text-green-600', bg: 'bg-green-50', to: '/lomba-saya?status=selesai' },
        ].map(s => (
          <Link key={s.label} to={s.to} className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-md hover:border-slate-300 transition-all block">
            <p className={`text-3xl font-extrabold ${s.color}`}>{s.value}</p>
            <p className="text-slate-500 text-sm mt-1">{s.label}</p>
          </Link>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Agenda mendatang */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-extrabold text-slate-900">Agenda Mendatang</h2>
            <Link to="/lomba-saya" className="text-xs text-[#254feb] font-semibold hover:underline">Lihat semua →</Link>
          </div>
          {upcoming.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">Tidak ada agenda mendatang</div>
          ) : (
            <ul className="divide-y divide-slate-50">
              {upcoming.map(t => (
                <li key={t.id} className="px-5 py-3.5 flex items-center gap-4">
                  <div className="text-center shrink-0 w-10">
                    <p className="text-xs text-slate-400">{new Date(t.tanggal).toLocaleDateString('id-ID', { month: 'short' })}</p>
                    <p className="text-lg font-extrabold text-slate-900 leading-none">{new Date(t.tanggal).getDate()}</p>
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 truncate">{t.label}</p>
                    <p className="text-xs text-slate-500 truncate">{t.lombaNama}</p>
                  </div>
                  <Link to={`/lomba-saya/${t.lombaId}`} className="ml-auto text-xs text-[#254feb] font-medium hover:underline shrink-0">Detail →</Link>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Kelengkapan dokumen */}
        <div className="bg-white rounded-xl border border-slate-200">
          <div className="px-5 py-4 border-b border-slate-100">
            <h2 className="font-extrabold text-slate-900">Kelengkapan Dokumen</h2>
          </div>
          {berkasTidakLengkap.length === 0 ? (
            <div className="p-5 text-sm text-green-700 bg-green-50 m-4 rounded-lg">✓ Semua dokumen sudah lengkap</div>
          ) : (
            <ul className="divide-y divide-slate-50 px-4 py-2">
              {berkasTidakLengkap.map(l => (
                <li key={l.id} className="py-3 flex items-center gap-2">
                  <span className="text-amber-500 text-sm">⚠</span>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 truncate">{l.nama}</p>
                    <p className="text-xs text-amber-600">Belum ada berkas</p>
                  </div>
                  <Link to={`/lomba-saya/${l.id}`} className="ml-auto text-xs text-[#254feb] shrink-0">Lengkapi</Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Daftar lomba ringkas */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="font-extrabold text-slate-900">Lomba Saya</h2>
          <Link to="/lomba-saya" className="text-xs text-[#254feb] font-semibold hover:underline">Lihat semua →</Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                {['Nama Lomba', 'Bidang', 'Tingkat', 'Status', 'Capaian'].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wide text-slate-500">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {lomba.map(l => (
                <tr key={l.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3.5">
                    <Link to={`/lomba-saya/${l.id}`} className="font-semibold text-[#254feb] hover:underline">{l.nama}</Link>
                    <p className="text-xs text-slate-400">{l.penyelenggara}</p>
                  </td>
                  <td className="px-5 py-3.5 text-slate-600">{l.bidang}</td>
                  <td className="px-5 py-3.5 text-slate-600">{l.tingkat}</td>
                  <td className="px-5 py-3.5">
                    <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${statusColors[l.status]}`}>
                      {STATUS_LABELS[l.status]}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    {l.capaian ? (
                      <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${capaianColors[l.capaian]}`}>
                        {CAPAIAN_LABELS[l.capaian]}
                      </span>
                    ) : <span className="text-slate-300">-</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
