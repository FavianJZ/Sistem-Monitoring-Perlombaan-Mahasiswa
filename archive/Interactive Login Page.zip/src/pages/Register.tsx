import { useMemo, useState, FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth, berandaRole, emailTerpakai, nimTerpakai } from '../auth/AuthContext'

const imgLogo = '/assets/eba26.svg'

type Role = 'mahasiswa' | 'dosen' | 'admin'

const PERAN: { id: Role; label: string; desc: string }[] = [
  { id: 'mahasiswa', label: 'Mahasiswa', desc: 'Catat & unggah bukti lomba' },
  { id: 'dosen', label: 'Dosen', desc: 'Pantau lomba mahasiswa' },
  { id: 'admin', label: 'Admin Prodi', desc: 'Kelola arsip & laporan' },
]

const PRODI = [
  'Teknik Informatika',
  'Sistem Informasi',
  'Desain Komunikasi Visual',
  'Manajemen',
  'Akuntansi',
  'Teknik Industri',
]

const TAHUN = new Date().getFullYear()
const ANGKATAN = Array.from({ length: 8 }, (_, i) => TAHUN - i)

const inputCls =
  'mt-1.5 w-full border rounded-lg px-3 py-2.5 text-sm text-[#0f172b] placeholder:text-[#90a1b9] bg-white shadow-sm focus:outline-none focus:ring-2 transition'
const okCls = 'border-[#cad5e2] focus:ring-[#254feb]/30 focus:border-[#254feb]'
const errCls = 'border-red-400 focus:ring-red-200 focus:border-red-500'

function kekuatanSandi(p: string) {
  const syarat = [
    { ok: p.length >= 8, label: 'Minimal 8 karakter' },
    { ok: /[A-Za-z]/.test(p) && /\d/.test(p), label: 'Huruf dan angka' },
    { ok: /[^A-Za-z0-9]/.test(p) || (/[A-Z]/.test(p) && /[a-z]/.test(p)), label: 'Huruf besar-kecil atau simbol' },
  ]
  return { syarat, skor: syarat.filter(s => s.ok).length }
}

function Field({
  label, error, hint, children, required = true,
}: { label: string; error?: string; hint?: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="text-[#314158] font-medium text-sm flex gap-0.5">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      {children}
      {error
        ? <p className="text-xs text-red-600 mt-1">{error}</p>
        : hint && <p className="text-xs text-[#62748e] mt-1">{hint}</p>}
    </div>
  )
}

export default function Register() {
  const { daftar, memproses } = useAuth()
  const navigate = useNavigate()

  const [role, setRole] = useState<Role>('mahasiswa')
  const [f, setF] = useState({
    nama: '', email: '', nim: '', prodi: '', angkatan: String(TAHUN),
    password: '', konfirmasi: '', kodeAdmin: '',
  })
  const [setuju, setSetuju] = useState(false)
  const [lihat, setLihat] = useState(false)
  const [sentuh, setSentuh] = useState<Record<string, boolean>>({})
  const [errorServer, setErrorServer] = useState('')

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setF(prev => ({ ...prev, [k]: e.target.value }))
  const blur = (k: string) => () => setSentuh(s => ({ ...s, [k]: true }))

  const kuat = useMemo(() => kekuatanSandi(f.password), [f.password])

  const errors = useMemo(() => {
    const e: Record<string, string> = {}
    if (f.nama.trim().length < 3) e.nama = 'Nama lengkap minimal 3 karakter.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) e.email = 'Format email tidak valid.'
    else if (role !== 'admin' && !f.email.toLowerCase().endsWith('@binus.ac.id')) e.email = 'Gunakan email kampus (@binus.ac.id).'
    else if (emailTerpakai(f.email)) e.email = 'Email ini sudah terdaftar.'
    if (role === 'mahasiswa') {
      if (!/^\d{10}$/.test(f.nim)) e.nim = 'NIM harus 10 digit angka.'
      else if (nimTerpakai(f.nim)) e.nim = 'NIM ini sudah terdaftar.'
    }
    if (!f.prodi) e.prodi = 'Pilih program studi.'
    if (kuat.skor < 3) e.password = 'Kata sandi belum memenuhi semua syarat.'
    if (f.konfirmasi !== f.password || !f.konfirmasi) e.konfirmasi = 'Konfirmasi kata sandi tidak cocok.'
    if (role === 'admin' && !f.kodeAdmin.trim()) e.kodeAdmin = 'Kode verifikasi wajib diisi.'
    if (!setuju) e.setuju = 'Anda harus menyetujui ketentuan penggunaan.'
    return e
  }, [f, role, kuat.skor, setuju])

  const tampil = (k: string) => (sentuh[k] ? errors[k] : undefined)
  const cls = (k: string) => `${inputCls} ${tampil(k) ? errCls : okCls}`

  const handleSubmit = async (ev: FormEvent) => {
    ev.preventDefault()
    setErrorServer('')
    if (Object.keys(errors).length) {
      setSentuh(Object.fromEntries(Object.keys(f).concat('setuju').map(k => [k, true])))
      return
    }
    try {
      const user = await daftar({
        nama: f.nama, email: f.email, password: f.password, role, prodi: f.prodi,
        ...(role === 'mahasiswa' ? { nim: f.nim, angkatan: Number(f.angkatan) } : {}),
        ...(role === 'admin' ? { kodeAdmin: f.kodeAdmin.trim() } : {}),
      })
      navigate(berandaRole(user.role), { replace: true })
    } catch (err: unknown) {
      setErrorServer(err instanceof Error ? err.message : 'Pendaftaran gagal.')
    }
  }

  const warnaBar = ['bg-slate-200', 'bg-red-500', 'bg-amber-500', 'bg-emerald-500'][kuat.skor]
  const labelBar = ['', 'Lemah', 'Cukup', 'Kuat'][kuat.skor]

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      <div className="relative bg-[#0f172b] flex flex-col lg:w-[40%] overflow-hidden lg:sticky lg:top-0 lg:h-screen">
        <div className="relative z-10 flex flex-col flex-1 p-10">
          <div className="flex items-center gap-3">
            <div className="bg-[#f97316] rounded-xl h-11 w-11 flex items-center justify-center shrink-0">
              <img src={imgLogo} alt="" className="h-6 w-6" />
            </div>
            <span className="text-white font-extrabold text-lg tracking-tight">SiMonLomba</span>
          </div>
          <h1 className="mt-10 lg:mt-16 text-white font-extrabold text-3xl lg:text-4xl leading-[1.25] tracking-tight max-w-md">
            Mulai catat dan pantau perlombaan dari satu akun.
          </h1>
          <p className="mt-4 text-[#cad5e2] text-base leading-relaxed max-w-sm">
            Pilih peran Anda, lengkapi data singkat, lalu langsung masuk ke dasbor yang sesuai.
          </p>
          <ol className="mt-8 hidden lg:flex flex-col gap-4">
            {['Pilih peran', 'Lengkapi data diri', 'Buat kata sandi'].map((t, i) => (
              <li key={t} className="flex items-center gap-3 text-[#cad5e2] text-sm">
                <span className="h-7 w-7 rounded-full bg-white/10 text-white font-semibold text-xs flex items-center justify-center">{i + 1}</span>
                {t}
              </li>
            ))}
          </ol>
          <p className="text-[#90a1b9] text-xs mt-auto pt-8 hidden lg:block">
            Prototipe antarmuka. Akun disimpan lokal di peramban ini saja.
          </p>
        </div>
      </div>

      <div className="bg-[#f8fafc] flex items-start lg:items-center justify-center flex-1 p-6 sm:p-8">
        <div className="w-full max-w-lg py-4">
          <h2 className="text-[#0f172b] font-extrabold text-2xl tracking-tight">Buat akun</h2>
          <p className="text-[#45556c] text-sm mt-1">Sudah punya akun? <Link to="/login" className="text-[#254feb] font-semibold hover:underline">Masuk</Link></p>

          <form onSubmit={handleSubmit} noValidate className="mt-6 flex flex-col gap-4">
            <fieldset>
              <legend className="text-[#314158] font-medium text-sm">Daftar sebagai</legend>
              <div className="mt-1.5 grid grid-cols-1 sm:grid-cols-3 gap-2" role="radiogroup">
                {PERAN.map(p => {
                  const aktif = role === p.id
                  return (
                    <button
                      key={p.id} type="button" role="radio" aria-checked={aktif}
                      onClick={() => { setRole(p.id); setErrorServer('') }}
                      className={`text-left rounded-lg border px-3 py-2.5 transition cursor-pointer ${aktif ? 'border-[#254feb] bg-[#254feb]/5 ring-2 ring-[#254feb]/20' : 'border-[#cad5e2] bg-white hover:border-[#254feb]/40'}`}
                    >
                      <p className={`text-sm font-semibold ${aktif ? 'text-[#254feb]' : 'text-[#0f172b]'}`}>{p.label}</p>
                      <p className="text-xs text-[#62748e] mt-0.5 leading-snug">{p.desc}</p>
                    </button>
                  )
                })}
              </div>
            </fieldset>

            <Field label="Nama lengkap" error={tampil('nama')}>
              <input value={f.nama} onChange={set('nama')} onBlur={blur('nama')} placeholder="Nama sesuai identitas" autoComplete="name" className={cls('nama')} />
            </Field>

            <Field label="Email" error={tampil('email')} hint={role === 'admin' ? undefined : 'Gunakan email kampus.'}>
              <input type="email" value={f.email} onChange={set('email')} onBlur={blur('email')} placeholder="nama@binus.ac.id" autoComplete="email" className={cls('email')} />
            </Field>

            {role === 'mahasiswa' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="NIM" error={tampil('nim')}>
                  <input inputMode="numeric" maxLength={10} value={f.nim} onChange={e => setF(p => ({ ...p, nim: e.target.value.replace(/\D/g, '') }))} onBlur={blur('nim')} placeholder="10 digit" className={cls('nim')} />
                </Field>
                <Field label="Angkatan">
                  <select value={f.angkatan} onChange={set('angkatan')} className={`${inputCls} ${okCls}`}>
                    {ANGKATAN.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                </Field>
              </div>
            )}

            {role !== 'admin' ? (
              <Field label="Program studi" error={tampil('prodi')}>
                <select value={f.prodi} onChange={set('prodi')} onBlur={blur('prodi')} className={cls('prodi')}>
                  <option value="">Pilih program studi</option>
                  {PRODI.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </Field>
            ) : (
              <>
                <Field label="Program studi" error={tampil('prodi')}>
                  <select value={f.prodi} onChange={set('prodi')} onBlur={blur('prodi')} className={cls('prodi')}>
                    <option value="">Pilih program studi</option>
                    {PRODI.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </Field>
                <Field label="Kode verifikasi Admin Prodi" error={tampil('kodeAdmin')} hint="Kode diberikan oleh pengelola sistem. Untuk demo: PRODI2026.">
                  <input value={f.kodeAdmin} onChange={set('kodeAdmin')} onBlur={blur('kodeAdmin')} placeholder="Masukkan kode" className={cls('kodeAdmin')} />
                </Field>
              </>
            )}

            <Field label="Kata sandi" error={tampil('password')}>
              <div className="relative">
                <input
                  type={lihat ? 'text' : 'password'} value={f.password} onChange={set('password')} onBlur={blur('password')}
                  placeholder="Buat kata sandi" autoComplete="new-password" className={`${cls('password')} pr-16`}
                />
                <button type="button" onClick={() => setLihat(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 mt-[3px] text-xs font-semibold text-[#254feb] cursor-pointer">
                  {lihat ? 'Sembunyikan' : 'Lihat'}
                </button>
              </div>
              {f.password && (
                <div className="mt-2">
                  <div className="flex gap-1.5 items-center">
                    {[1, 2, 3].map(i => <span key={i} className={`h-1.5 flex-1 rounded-full ${i <= kuat.skor ? warnaBar : 'bg-slate-200'}`} />)}
                    <span className="text-xs font-semibold text-[#45556c] w-12 text-right">{labelBar}</span>
                  </div>
                  <ul className="mt-1.5 grid grid-cols-1 sm:grid-cols-3 gap-x-3 gap-y-0.5">
                    {kuat.syarat.map(s => (
                      <li key={s.label} className={`text-xs ${s.ok ? 'text-emerald-600' : 'text-[#62748e]'}`}>{s.ok ? '✓' : '•'} {s.label}</li>
                    ))}
                  </ul>
                </div>
              )}
            </Field>

            <Field label="Konfirmasi kata sandi" error={tampil('konfirmasi')}>
              <input type={lihat ? 'text' : 'password'} value={f.konfirmasi} onChange={set('konfirmasi')} onBlur={blur('konfirmasi')} placeholder="Ulangi kata sandi" autoComplete="new-password" className={cls('konfirmasi')} />
            </Field>

            <div>
              <label className="flex gap-2.5 items-start text-sm text-[#45556c] cursor-pointer">
                <input type="checkbox" checked={setuju} onChange={e => { setSetuju(e.target.checked); setSentuh(s => ({ ...s, setuju: true })) }} className="mt-0.5 h-4 w-4 accent-[#254feb]" />
                <span>Saya menyetujui ketentuan penggunaan dan kebijakan data SiMonLomba.</span>
              </label>
              {tampil('setuju') && <p className="text-xs text-red-600 mt-1">{errors.setuju}</p>}
            </div>

            {errorServer && <p role="alert" className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{errorServer}</p>}

            <button
              type="submit" disabled={memproses}
              className="w-full h-11 bg-[#254feb] hover:bg-[#1d3fd4] active:bg-[#1835c2] disabled:opacity-70 text-white font-semibold text-base rounded-lg flex items-center justify-center gap-2 transition-colors shadow-sm cursor-pointer"
            >
              {memproses && <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4l3-3-3-3v4a8 8 0 00-8 8h4z" /></svg>}
              {memproses ? 'Membuat akun...' : 'Buat akun'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
