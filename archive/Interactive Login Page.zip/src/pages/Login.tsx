import { useState, FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth, berandaRole } from '../auth/AuthContext'
import { AKUN_DEMO } from '../data/mockData'

const imgLogo = '/assets/eba26.svg'
const imgMail = '/assets/b87ed.svg'
const imgClock = '/assets/77781.svg'
const imgTrophy = '/assets/0d403.svg'
const imgArrow = '/assets/0156a.svg'
const imgLoginIcon = '/assets/07017.svg'

export default function Login() {
  const { masuk, masukCepat, memproses } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      const user = await masuk({ email, password })
      navigate(berandaRole(user.role), { replace: true })
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Login gagal.')
    }
  }

  const handleDemo = async (id: string) => {
    setError('')
    try {
      const user = await masukCepat(id)
      navigate(berandaRole(user.role), { replace: true })
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Login gagal.')
    }
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left dark panel */}
      <div className="relative bg-[#0f172b] flex flex-col lg:w-[52%] overflow-hidden min-h-[300px] lg:min-h-screen">

        <div className="relative z-10 flex flex-col flex-1 p-10">
          <div className="flex items-center gap-3">
            <div className="bg-[#f97316] rounded-xl h-11 w-11 flex items-center justify-center shrink-0">
              <img src={imgLogo} alt="" className="h-6 w-6" />
            </div>
            <span className="text-white font-extrabold text-lg tracking-tight">SiMonLomba</span>
          </div>

          <div className="mt-12">
            <h1 className="text-white font-extrabold text-4xl leading-[1.25] tracking-tight max-w-md">
              Setiap lomba mahasiswa tercatat, terpantau, dan siap dilaporkan.
            </h1>
            <p className="mt-4 text-[#cad5e2] text-base leading-relaxed max-w-sm">
              Sistem Monitoring Perlombaan Mahasiswa mengumpulkan data keikutsertaan beserta bukti pendukungnya, lalu menyajikannya untuk pemantauan program studi.
            </p>
          </div>

          <div className="mt-auto pt-10 flex flex-col gap-5">
            {[
              { icon: imgMail, title: 'Bukti terkumpul di satu tempat', desc: 'Bukti pendaftaran, pembayaran, poster, dan susunan tim tersimpan rapi per lomba.' },
              { icon: imgClock, title: 'Timeline yang terpantau', desc: 'Dari pendaftaran, technical meeting, penyisihan, sampai pengumuman pemenang.' },
              { icon: imgTrophy, title: 'Arsip prestasi siap dilaporkan', desc: 'Rekap capaian dan sertifikat untuk kebutuhan akreditasi program studi.' },
            ].map(f => (
              <div key={f.title} className="flex gap-4 items-start">
                <div className="bg-white/10 rounded-xl h-10 w-10 flex items-center justify-center shrink-0">
                  <img src={f.icon} alt="" className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-white font-semibold text-base leading-6">{f.title}</p>
                  <p className="text-[#cad5e2] text-sm leading-5">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <p className="text-[#90a1b9] text-xs mt-8">
            Prototipe antarmuka. Data masih tiruan dan belum tersambung ke basis data.
          </p>
        </div>
      </div>

      {/* Right panel */}
      <div className="bg-[#f8fafc] flex items-center justify-center flex-1 p-8">
        <div className="w-full max-w-md">
          <h2 className="text-[#0f172b] font-extrabold text-2xl tracking-tight">Masuk</h2>
          <p className="text-[#45556c] text-sm mt-1">Gunakan akun kampus Anda untuk melanjutkan.</p>

          <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4">
            <div>
              <label className="text-[#314158] font-medium text-sm flex gap-0.5">Email <span className="text-red-600">*</span></label>
              <input
                type="email" value={email} onChange={e => setEmail(e.target.value)} required
                placeholder="nama@binus.ac.id"
                className="mt-1.5 w-full border border-[#cad5e2] rounded-lg px-3 py-2.5 text-sm text-[#0f172b] placeholder:text-[#90a1b9] bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 focus:border-[#254feb] transition"
              />
            </div>
            <div>
              <label className="text-[#314158] font-medium text-sm flex gap-0.5">Kata Sandi <span className="text-red-600">*</span></label>
              <input
                type="password" value={password} onChange={e => setPassword(e.target.value)} required
                placeholder="Masukkan kata sandi"
                className="mt-1.5 w-full border border-[#cad5e2] rounded-lg px-3 py-2.5 text-sm text-[#0f172b] placeholder:text-[#90a1b9] bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 focus:border-[#254feb] transition"
              />
            </div>
            {error && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</p>}
            <button
              type="submit" disabled={memproses}
              className="w-full h-11 bg-[#254feb] hover:bg-[#1d3fd4] active:bg-[#1835c2] disabled:opacity-70 text-white font-semibold text-base rounded-lg flex items-center justify-center gap-2 transition-colors shadow-sm cursor-pointer"
            >
              {memproses
                ? <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4l3-3-3-3v4a8 8 0 00-8 8h4z" /></svg>
                : <img src={imgLoginIcon} alt="" className="h-4 w-4" />
              }
              {memproses ? 'Memproses...' : 'Masuk'}
            </button>
          </form>

          <p className="mt-5 text-sm text-[#45556c] text-center">
            Belum punya akun?{' '}
            <Link to="/daftar" className="text-[#254feb] font-semibold hover:underline">Daftar sekarang</Link>
          </p>

          {/* Demo accounts */}
          <div className="mt-8 bg-white border border-[#e2e8f0] rounded-xl p-4">
            <p className="text-[#0f172b] font-semibold text-sm">Akun demo</p>
            <p className="text-[#62748e] text-xs mt-0.5">
              Kata sandi semua akun demo: <code className="font-mono font-bold">demo1234</code>
            </p>
            <div className="mt-3 flex flex-col gap-2">
              {AKUN_DEMO.map(akun => (
                <button
                  key={akun.id}
                  onClick={() => handleDemo(akun.id)}
                  disabled={memproses}
                  className="flex items-center justify-between px-3.5 py-2.5 rounded-lg border border-[#e2e8f0] hover:bg-slate-50 hover:border-[#254feb]/30 transition-colors w-full text-left cursor-pointer disabled:opacity-60"
                >
                  <div>
                    <p className="text-[#0f172b] font-semibold text-sm">{akun.label}</p>
                    <p className="text-[#62748e] text-xs">{akun.keterangan}</p>
                  </div>
                  <img src={imgArrow} alt="" className="h-4 w-4 shrink-0" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
