import { useState } from 'react'
import { Link } from 'react-router-dom'
import { DATA_LOMBA, MAHASISWA, STATUS_LABELS, CAPAIAN_LABELS, namaPengguna } from '../../data/mockData'
import { useAuth } from '../../auth/AuthContext'

const statusColors: Record<string, string> = {
  terdaftar: 'bg-blue-50 text-blue-700 border border-blue-200',
  berlangsung: 'bg-amber-50 text-amber-700 border border-amber-200',
  selesai: 'bg-green-50 text-green-700 border border-green-200',
}

const capaianColors: Record<string, string> = {
  juara_1: 'bg-yellow-50 text-yellow-700',
  juara_2: 'bg-slate-100 text-slate-600',
  juara_3: 'bg-orange-50 text-orange-600',
  harapan: 'bg-purple-50 text-purple-600',
  finalis: 'bg-indigo-50 text-indigo-600',
  peserta: 'bg-slate-50 text-slate-500',
}

export default function DashboardMonitoring() {
  const { user } = useAuth()
  const [hanyaBimbingan, setHanyaBimbingan] = useState(false)

  const lomba = hanyaBimbingan ? DATA_LOMBA.filter(l => l.dosenId === user?.id) : DATA_LOMBA

  const stats = {
    total: DATA_LOMBA.length,
    berlangsung: DATA_LOMBA.filter(l => l.status === 'berlangsung').length,
    selesai: DATA_LOMBA.filter(l => l.status === 'selesai').length,
    terdaftar: DATA_LOMBA.filter(l => l.status === 'terdaftar').length,
    mahasiswa: MAHASISWA.length,
    prestasi: DATA_LOMBA.filter(l => l.capaian && l.capaian !== 'peserta').length,
  }

  const upcoming = DATA_LOMBA
    .flatMap(l => l.tahapan.filter(t => !t.selesai).map(t => ({ ...t, lombaId: l.id, lombaNama: l.nama })))
    .sort((a, b) => a.tanggal.localeCompare(b.tanggal))
    .slice(0, 5)

  const bidangCount: Record<string, number> = {}
  DATA_LOMBA.forEach(l => { bidangCount[l.bidang] = (bidangCount[l.bidang] ?? 0) + 1 })

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Dashboard Monitoring</h1>
          <p className="text-sm text-slate-500 mt-0.5">Pantau perkembangan lomba mahasiswa program studi.</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer text-sm text-slate-600">
            <input type="checkbox" checked={hanyaBimbingan} onChange={e => setHanyaBimbingan(e.target.checked)} className="rounded" />
            Hanya bimbingan saya
          </label>
          <Link to="/monitoring/lomba" className="inline-flex items-center gap-2 bg-[#254feb] hover:bg-[#1d3fd4] text-white font-semibold text-sm px-4 py-2 rounded-lg transition-colors">
            Lihat Semua Lomba
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { label: 'Total Lomba', value: stats.total, color: 'text-[#254feb]', to: '/monitoring/lomba' },
          { label: 'Berlangsung', value: stats.berlangsung, color: 'text-amber-600', to: '/monitoring/lomba?status=berlangsung' },
          { label: 'Terdaftar', value: stats.terdaftar, color: 'text-sky-600', to: '/monitoring/lomba?status=terdaftar' },
          { label: 'Selesai', value: stats.selesai, color: 'text-green-600', to: '/monitoring/lomba?status=selesai' },
          { label: 'Mahasiswa Aktif', value: stats.mahasiswa, color: 'text-violet-600', to: '/monitoring/lomba' },
          { label: 'Prestasi', value: stats.prestasi, color: 'text-rose-500', to: '/monitoring/arsip' },
        ].map(s => (
          <Link key={s.label} to={s.to} className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-md hover:border-slate-300 transition-all block">
            <p className={`text-2xl font-extrabold ${s.color}`}>{s.value}</p>
            <p className="text-slate-500 text-xs mt-1">{s.label}</p>
          </Link>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Agenda mendatang */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-extrabold text-slate-900">Agenda Mendatang</h2>
            <Link to="/monitoring/kalender" className="text-xs text-[#254feb] font-semibold hover:underline">Kalender →</Link>
          </div>
          {upcoming.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">Tidak ada agenda</div>
          ) : (
            <ul className="divide-y divide-slate-50">
              {upcoming.map(t => (
                <li key={t.id} className="px-5 py-3.5 flex items-center gap-4">
                  <div className="text-center shrink-0 w-10">
                    <p className="text-xs text-slate-400">{new Date(t.tanggal).toLocaleDateString('id-ID', { month: 'short' })}</p>
                    <p className="text-lg font-extrabold text-slate-900 leading-none">{new Date(t.tanggal).getDate()}</p>
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 truncate">{t.label}</p>
                    <p className="text-xs text-slate-500 truncate">{t.lombaNama}</p>
                  </div>
                  <Link to={`/monitoring/lomba/${t.lombaId}`} className="ml-auto text-xs text-[#254feb] font-medium hover:underline shrink-0">Detail →</Link>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Sebaran bidang */}
        <div className="bg-white rounded-xl border border-slate-200">
          <div className="px-5 py-4 border-b border-slate-100">
            <h2 className="font-extrabold text-slate-900">Sebaran Bidang</h2>
          </div>
          <div className="p-5 space-y-3">
            {Object.entries(bidangCount).sort((a, b) => b[1] - a[1]).map(([bidang, count]) => (
              <div key={bidang}>
                <div className="flex justify-between text-xs text-slate-600 mb-1">
                  <span>{bidang}</span><span className="font-semibold">{count}</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-[#254feb] rounded-full" style={{ width: `${(count / DATA_LOMBA.length) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lomba cards */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-extrabold text-slate-900">Daftar Lomba {hanyaBimbingan ? '(Bimbingan Saya)' : ''}</h2>
          <Link to="/monitoring/lomba" className="text-xs text-[#254feb] font-semibold hover:underline">Lihat semua →</Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {lomba.slice(0, 6).map(l => (
            <Link key={l.id} to={`/monitoring/lomba/${l.id}`}
              className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-md hover:border-[#254feb]/30 transition-all block group">
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[l.status]}`}>{STATUS_LABELS[l.status]}</span>
                <span className="text-xs text-slate-400">{l.tingkat}</span>
              </div>
              <h3 className="font-semibold text-slate-900 text-sm group-hover:text-[#254feb] transition-colors">{l.nama}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{l.penyelenggara}</p>
              <div className="mt-3 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="h-5 w-5 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600">
                    {namaPengguna(l.mahasiswaId).charAt(0)}
                  </div>
                  <span className="text-xs text-slate-500 truncate max-w-[100px]">{namaPengguna(l.mahasiswaId)}</span>
                </div>
                {l.capaian && (
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${capaianColors[l.capaian]}`}>{CAPAIAN_LABELS[l.capaian]}</span>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
