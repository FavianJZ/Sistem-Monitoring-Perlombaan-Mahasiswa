import { useState } from 'react'
import { Link } from 'react-router-dom'
import { DATA_LOMBA } from '../../data/mockData'

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate()
}
function getFirstDayOfMonth(year: number, month: number) {
  return new Date(year, month, 1).getDay()
}

const MONTHS_ID = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
const DAYS_ID = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab']

interface AgendaItem { tanggal: string; label: string; lombaId: string; lombaNama: string }

export default function KalenderAgenda() {
  const today = new Date()
  const [year, setYear] = useState(today.getFullYear())
  const [month, setMonth] = useState(today.getMonth())
  const [selected, setSelected] = useState<string | null>(null)

  const allAgenda: AgendaItem[] = DATA_LOMBA.flatMap(l =>
    l.tahapan.map(t => ({ tanggal: t.tanggal, label: t.label, lombaId: l.id, lombaNama: l.nama }))
  )

  const agendaByDate: Record<string, AgendaItem[]> = {}
  allAgenda.forEach(a => {
    if (!agendaByDate[a.tanggal]) agendaByDate[a.tanggal] = []
    agendaByDate[a.tanggal].push(a)
  })

  const daysInMonth = getDaysInMonth(year, month)
  const firstDay = getFirstDayOfMonth(year, month)
  const cells: (number | null)[] = [...Array(firstDay).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)]
  while (cells.length % 7 !== 0) cells.push(null)

  const prevMonth = () => { if (month === 0) { setYear(y => y - 1); setMonth(11) } else setMonth(m => m - 1) }
  const nextMonth = () => { if (month === 11) { setYear(y => y + 1); setMonth(0) } else setMonth(m => m + 1) }

  const selectedAgenda = selected ? (agendaByDate[selected] ?? []) : []

  const monthAgenda = allAgenda
    .filter(a => a.tanggal.startsWith(`${year}-${String(month + 1).padStart(2, '0')}`))
    .sort((a, b) => a.tanggal.localeCompare(b.tanggal))

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Kalender Agenda</h1>
        <p className="text-sm text-slate-500 mt-0.5">Jadwal tahapan semua lomba mahasiswa.</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
            <button onClick={prevMonth} className="h-8 w-8 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors cursor-pointer">‹</button>
            <h2 className="font-extrabold text-slate-900">{MONTHS_ID[month]} {year}</h2>
            <button onClick={nextMonth} className="h-8 w-8 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors cursor-pointer">›</button>
          </div>

          {/* Grid */}
          <div className="p-4">
            <div className="grid grid-cols-7 mb-2">
              {DAYS_ID.map(d => <div key={d} className="text-center text-xs font-semibold text-slate-400 py-1">{d}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {cells.map((day, idx) => {
                if (!day) return <div key={`empty-${idx}`} />
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
                const hasAgenda = Boolean(agendaByDate[dateStr])
                const isToday = dateStr === today.toISOString().split('T')[0]
                const isSelected = dateStr === selected
                return (
                  <button key={dateStr} onClick={() => setSelected(isSelected ? null : dateStr)}
                    className={`relative aspect-square rounded-lg flex flex-col items-center justify-start pt-1.5 text-sm transition-colors cursor-pointer ${
                      isSelected ? 'bg-[#254feb] text-white' :
                      isToday ? 'bg-[#254feb]/10 text-[#254feb] font-bold' :
                      hasAgenda ? 'hover:bg-slate-100 text-slate-900' :
                      'hover:bg-slate-50 text-slate-600'
                    }`}>
                    <span className="font-medium text-sm">{day}</span>
                    {hasAgenda && (
                      <div className={`h-1.5 w-1.5 rounded-full mt-0.5 ${isSelected ? 'bg-white' : 'bg-[#254feb]'}`} />
                    )}
                  </button>
                )
              })}
            </div>
          </div>
        </div>

        {/* Agenda panel */}
        <div className="bg-white rounded-xl border border-slate-200 flex flex-col">
          <div className="px-5 py-4 border-b border-slate-100">
            <h3 className="font-extrabold text-slate-900">
              {selected
                ? new Date(selected + 'T00:00:00').toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
                : `Agenda ${MONTHS_ID[month]}`
              }
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {(selected ? selectedAgenda : monthAgenda).length === 0 ? (
              <p className="text-slate-400 text-sm text-center py-8">Tidak ada agenda</p>
            ) : (
              (selected ? selectedAgenda : monthAgenda).map((a, i) => (
                <Link key={i} to={`/monitoring/lomba/${a.lombaId}`}
                  className="block p-3 bg-slate-50 hover:bg-[#254feb]/5 rounded-lg border border-slate-200 hover:border-[#254feb]/30 transition-colors">
                  <p className="text-sm font-semibold text-slate-900">{a.label}</p>
                  <p className="text-xs text-slate-500 mt-0.5 truncate">{a.lombaNama}</p>
                  {!selected && <p className="text-xs text-slate-400 mt-0.5">{new Date(a.tanggal + 'T00:00:00').toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}</p>}
                </Link>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
