import { useState } from 'react'
import { DATA_LOMBA, CAPAIAN_LABELS, namaPengguna } from '../../data/mockData'

const CAPAIAN_COLORS: Record<string, string> = {
  juara_1: 'bg-yellow-50 text-yellow-700 border border-yellow-200',
  juara_2: 'bg-slate-50 text-slate-600 border border-slate-200',
  juara_3: 'bg-orange-50 text-orange-600 border border-orange-200',
  harapan: 'bg-purple-50 text-purple-700 border border-purple-200',
  finalis: 'bg-indigo-50 text-indigo-600 border border-indigo-200',
  peserta: 'bg-slate-50 text-slate-500 border border-slate-200',
}

const CAPAIAN_EMOJI: Record<string, string> = {
  juara_1: '🥇', juara_2: '🥈', juara_3: '🥉',
  harapan: '🏅', finalis: '⭐', peserta: '📋',
}

export default function ArsipPrestasi() {
  const [query, setQuery] = useState('')
  const [capaianFilter, setCapaianFilter] = useState('')

  const arsip = DATA_LOMBA.filter(l => l.status === 'selesai' && l.capaian)

  const filtered = arsip.filter(l => {
    const q = query.toLowerCase()
    const matchQ = !q || l.nama.toLowerCase().includes(q) || namaPengguna(l.mahasiswaId).toLowerCase().includes(q)
    const matchC = !capaianFilter || l.capaian === capaianFilter
    return matchQ && matchC
  })

  const stats = {
    total: arsip.length,
    juara: arsip.filter(l => l.capaian?.startsWith('juara')).length,
    finalis: arsip.filter(l => l.capaian === 'finalis' || l.capaian === 'harapan').length,
    peserta: arsip.filter(l => l.capaian === 'peserta').length,
  }

  const capaianDist: Record<string, number> = {}
  arsip.forEach(l => { if (l.capaian) capaianDist[l.capaian] = (capaianDist[l.capaian] ?? 0) + 1 })

  const handleExport = (type: string) => {
    alert(`Fitur ekspor ${type} akan tersedia segera.`)
  }

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Arsip Prestasi</h1>
          <p className="text-sm text-slate-500 mt-0.5">Rekap capaian lomba mahasiswa untuk akreditasi program studi.</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {['CSV', 'Excel', 'PDF'].map(t => (
            <button key={t} onClick={() => handleExport(t)}
              className="text-sm font-medium border border-slate-200 px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-colors text-slate-600">
              ↓ {t}
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Prestasi', value: stats.total, color: 'text-[#254feb]' },
          { label: 'Juara (1–3)', value: stats.juara, color: 'text-yellow-600' },
          { label: 'Finalis / Harapan', value: stats.finalis, color: 'text-indigo-600' },
          { label: 'Peserta', value: stats.peserta, color: 'text-slate-500' },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-200 p-4">
            <p className={`text-3xl font-extrabold ${s.color}`}>{s.value}</p>
            <p className="text-slate-500 text-sm mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Capaian distribution */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="font-extrabold text-slate-900 mb-4">Sebaran Capaian</h3>
        <div className="flex flex-wrap gap-2">
          {Object.entries(capaianDist).sort((a, b) => b[1] - a[1]).map(([k, v]) => (
            <span key={k} className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-semibold border ${CAPAIAN_COLORS[k] ?? 'bg-slate-50 text-slate-600 border border-slate-200'}`}>
              {CAPAIAN_EMOJI[k]} {CAPAIAN_LABELS[k]} <span className="bg-white/60 rounded-full px-1.5 py-0.5 text-xs font-bold">{v}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Filter + table */}
      <div className="flex flex-col sm:flex-row gap-3">
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Cari nama lomba atau mahasiswa..."
          className="flex-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 focus:border-[#254feb] bg-white" />
        <select value={capaianFilter} onChange={e => setCapaianFilter(e.target.value)}
          className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 bg-white">
          <option value="">Semua Capaian</option>
          {Object.entries(CAPAIAN_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                {['Nama Lomba', 'Penyelenggara', 'Mahasiswa', 'Bidang', 'Tingkat', 'Capaian', 'Berkas'].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map(l => (
                <tr key={l.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3.5">
                    <p className="font-semibold text-slate-900">{l.nama}</p>
                    <p className="text-xs text-slate-400">{new Date(l.tanggalSelesai).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                  </td>
                  <td className="px-5 py-3.5 text-slate-600 text-xs">{l.penyelenggara}</td>
                  <td className="px-5 py-3.5 text-slate-700 text-xs font-medium">{namaPengguna(l.mahasiswaId)}</td>
                  <td className="px-5 py-3.5 text-slate-600">{l.bidang}</td>
                  <td className="px-5 py-3.5 text-slate-600">{l.tingkat}</td>
                  <td className="px-5 py-3.5">
                    {l.capaian && (
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${CAPAIAN_COLORS[l.capaian] ?? ''}`}>
                        {CAPAIAN_EMOJI[l.capaian]} {CAPAIAN_LABELS[l.capaian]}
                      </span>
                    )}
                  </td>
                  <td className="px-5 py-3.5">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${l.berkas.length > 0 ? 'bg-green-50 text-green-600' : 'bg-amber-50 text-amber-600'}`}>
                      {l.berkas.length > 0 ? `${l.berkas.length} berkas` : 'Belum ada'}
                    </span>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="py-12 text-center text-slate-400 text-sm">Tidak ada data</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
