import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { DATA_LOMBA, STATUS_LABELS, CAPAIAN_LABELS, namaPengguna, type StatusLomba } from '../../data/mockData'

const statusColors: Record<string, string> = {
  terdaftar: 'bg-blue-50 text-blue-700 border border-blue-200',
  berlangsung: 'bg-amber-50 text-amber-700 border border-amber-200',
  selesai: 'bg-green-50 text-green-700 border border-green-200',
}

const capaianColors: Record<string, string> = {
  juara_1: 'bg-yellow-50 text-yellow-700 border border-yellow-200',
  juara_2: 'bg-slate-50 text-slate-600 border border-slate-200',
  juara_3: 'bg-orange-50 text-orange-600 border border-orange-200',
  harapan: 'bg-purple-50 text-purple-700 border border-purple-200',
  finalis: 'bg-indigo-50 text-indigo-600 border border-indigo-200',
  peserta: 'bg-slate-50 text-slate-500 border border-slate-200',
}

export default function MonitoringLomba() {
  const [searchParams] = useSearchParams()
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState<StatusLomba | ''>((searchParams.get('status') as StatusLomba) ?? '')
  const [view, setView] = useState<'table' | 'card'>('table')

  const filtered = DATA_LOMBA.filter(l => {
    const q = query.toLowerCase()
    const matchQ = !q || l.nama.toLowerCase().includes(q) || l.penyelenggara.toLowerCase().includes(q) || l.bidang.toLowerCase().includes(q)
    const matchS = !status || l.status === status
    return matchQ && matchS
  })

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900">Monitoring Lomba</h1>
          <p className="text-sm text-slate-500 mt-0.5">{DATA_LOMBA.length} lomba tercatat</p>
        </div>
        <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
          <button onClick={() => setView('table')} className={`px-3 py-1.5 rounded-md text-sm font-semibold transition-colors cursor-pointer ${view === 'table' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}>☰ Tabel</button>
          <button onClick={() => setView('card')} className={`px-3 py-1.5 rounded-md text-sm font-semibold transition-colors cursor-pointer ${view === 'card' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}>⊞ Kartu</button>
        </div>
      </div>

      {/* Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Cari nama, penyelenggara, bidang..."
          className="flex-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 focus:border-[#254feb] bg-white" />
        <select value={status} onChange={e => setStatus(e.target.value as StatusLomba | '')}
          className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#254feb]/30 bg-white">
          <option value="">Semua Status</option>
          <option value="terdaftar">Terdaftar</option>
          <option value="berlangsung">Berlangsung</option>
          <option value="selesai">Selesai</option>
        </select>
      </div>

      {view === 'table' ? (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  {['Nama Lomba', 'Penyelenggara', 'Bidang', 'Mahasiswa', 'Status', 'Capaian', ''].map(h => (
                    <th key={h} className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map(l => (
                  <tr key={l.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3.5">
                      <p className="font-semibold text-slate-900">{l.nama}</p>
                      <p className="text-xs text-slate-400">{l.tingkat}</p>
                    </td>
                    <td className="px-5 py-3.5 text-slate-600 text-xs">{l.penyelenggara}</td>
                    <td className="px-5 py-3.5 text-slate-600">{l.bidang}</td>
                    <td className="px-5 py-3.5 text-slate-600 text-xs">{namaPengguna(l.mahasiswaId)}</td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${statusColors[l.status]}`}>{STATUS_LABELS[l.status]}</span>
                    </td>
                    <td className="px-5 py-3.5">
                      {l.capaian ? (
                        <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${capaianColors[l.capaian]}`}>{CAPAIAN_LABELS[l.capaian]}</span>
                      ) : <span className="text-slate-300 text-xs">-</span>}
                    </td>
                    <td className="px-5 py-3.5">
                      <Link to={`/monitoring/lomba/${l.id}`} className="text-[#254feb] text-xs font-medium hover:underline">Detail →</Link>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={7} className="py-12 text-center text-slate-400 text-sm">Tidak ada data</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(l => (
            <Link key={l.id} to={`/monitoring/lomba/${l.id}`}
              className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-md hover:border-[#254feb]/30 transition-all block group">
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[l.status]}`}>{STATUS_LABELS[l.status]}</span>
                <span className="text-xs text-slate-400">{l.tingkat}</span>
              </div>
              <h3 className="font-semibold text-slate-900 text-sm group-hover:text-[#254feb] transition-colors">{l.nama}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{l.penyelenggara}</p>
              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-500">{namaPengguna(l.mahasiswaId)}</span>
                {l.capaian && <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${capaianColors[l.capaian]}`}>{CAPAIAN_LABELS[l.capaian]}</span>}
              </div>
            </Link>
          ))}
          {filtered.length === 0 && (
            <div className="sm:col-span-3 py-16 text-center text-slate-400 text-sm bg-white rounded-xl border border-slate-200">Tidak ada data</div>
          )}
        </div>
      )}
    </div>
  )
}
