import { useAuth } from '../../auth/AuthContext'

const ROLE_LABELS: Record<string, string> = {
  mahasiswa: 'Mahasiswa', dosen: 'Dosen', admin: 'Admin Prodi',
}

export default function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
  const { user, role, keluar } = useAuth()

  return (
    <header className="flex h-14 items-center border-b border-slate-200 bg-white px-5 gap-4">
      <button
        onClick={onMenuClick}
        className="text-slate-500 hover:text-slate-800 lg:hidden"
        aria-label="Buka menu"
      >
        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" />
        </svg>
      </button>

      <div className="ml-auto flex items-center gap-3">
        <div className="text-right hidden sm:block">
          <p className="text-sm font-semibold text-slate-900">{user?.nama}</p>
          <p className="text-xs text-slate-500">{ROLE_LABELS[role ?? ''] ?? role}</p>
        </div>
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#254feb]/10 text-[#254feb] text-xs font-bold">
          {user?.nama?.charAt(0) ?? '?'}
        </div>
        <button onClick={keluar} className="text-sm text-slate-500 hover:text-red-500 border border-slate-200 px-2.5 py-1 rounded-lg transition-colors">
          Keluar
        </button>
      </div>
    </header>
  )
}
