import { NavLink } from 'react-router-dom'
import { useAuth } from '../../auth/AuthContext'

const imgLogo = '/assets/eba26.svg'

interface NavItem { to: string; label: string; icon: string; end?: boolean }

const NAV_MAHASISWA: NavItem[] = [
  { to: '/', label: 'Dashboard', icon: '⊞', end: true },
  { to: '/lomba-saya', label: 'Lomba Saya', icon: '🏆' },
  { to: '/profil', label: 'Profil', icon: '👤' },
]

const NAV_DOSEN: NavItem[] = [
  { to: '/monitoring', label: 'Dashboard Monitoring', icon: '⊞', end: true },
  { to: '/monitoring/lomba', label: 'Monitoring Lomba', icon: '🏆' },
  { to: '/monitoring/kalender', label: 'Kalender Agenda', icon: '📅' },
  { to: '/monitoring/arsip', label: 'Arsip Prestasi', icon: '📁' },
  { to: '/profil', label: 'Profil', icon: '👤' },
]

const ROLE_LABELS: Record<string, string> = {
  mahasiswa: 'Mahasiswa', dosen: 'Dosen', admin: 'Admin Prodi',
}

export default function Sidebar({ onClose }: { onClose: () => void }) {
  const { user, role, keluar } = useAuth()
  const navItems = (role === 'dosen' || role === 'admin') ? NAV_DOSEN : NAV_MAHASISWA

  return (
    <nav className="flex h-full flex-col bg-white border-r border-slate-200">
      {/* Logo */}
      <div className="flex h-16 items-center gap-3 border-b border-slate-100 px-5">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#f97316]">
          <img src={imgLogo} alt="" className="h-5 w-5" />
        </div>
        <span className="text-[15px] font-extrabold tracking-tight text-slate-900">SiMonLomba</span>
        <button onClick={onClose} className="ml-auto text-slate-400 hover:text-slate-600 lg:hidden" aria-label="Tutup sidebar">✕</button>
      </div>

      {/* Nav */}
      <div className="flex-1 overflow-y-auto py-4 px-3">
        <ul className="space-y-0.5">
          {navItems.map(item => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-[#254feb]/10 text-[#254feb]'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`
                }
              >
                <span className="text-base leading-none">{item.icon}</span>
                {item.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </div>

      {/* User */}
      <div className="border-t border-slate-100 p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#254feb]/10 text-[#254feb] text-xs font-bold">
            {user?.nama?.charAt(0) ?? '?'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-semibold text-slate-900">{user?.nama}</p>
            <p className="text-[11px] text-slate-500">{ROLE_LABELS[role ?? ''] ?? role}</p>
          </div>
          <button onClick={keluar} className="text-xs text-slate-400 hover:text-red-500 transition-colors" title="Keluar">↩</button>
        </div>
      </div>
    </nav>
  )
}
