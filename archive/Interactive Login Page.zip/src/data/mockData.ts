export const SANDI_DEMO = 'demo1234'

export interface Pengguna {
  id: string
  nama: string
  email: string
  role: 'mahasiswa' | 'dosen' | 'admin'
  nim?: string
  prodi: string
  angkatan?: number
}

export const MAHASISWA: Pengguna[] = [
  { id: 'mhs-1', nama: 'Aulia Rahmawati', email: 'aulia.rahmawati@binus.ac.id', role: 'mahasiswa', nim: '2502019876', prodi: 'Teknik Informatika', angkatan: 2025 },
  { id: 'mhs-2', nama: 'Bagas Prayoga', email: 'bagas.prayoga@binus.ac.id', role: 'mahasiswa', nim: '2502011234', prodi: 'Sistem Informasi', angkatan: 2025 },
  { id: 'mhs-3', nama: 'Citra Maheswari', email: 'citra.maheswari@binus.ac.id', role: 'mahasiswa', nim: '2502015678', prodi: 'Desain Komunikasi Visual', angkatan: 2025 },
]

export const DOSEN: Pengguna[] = [
  { id: 'dsn-1', nama: 'Pandu Wicaksono, S.Kom., M.Kom.', email: 'pandu.wicaksono@binus.ac.id', role: 'dosen', prodi: 'Teknik Informatika' },
  { id: 'dsn-2', nama: 'Ratna Kusumawati, S.T., M.T.', email: 'ratna.kusumawati@binus.ac.id', role: 'dosen', prodi: 'Manajemen' },
]

export const ADMIN: Pengguna[] = [
  { id: 'adm-1', nama: 'Yulia Hartanti', email: 'yulia.hartanti@binus.ac.id', role: 'admin', prodi: 'Program Studi' },
]

export const SEMUA_PENGGUNA: Pengguna[] = [...MAHASISWA, ...DOSEN, ...ADMIN]

export const AKUN_DEMO = [
  { id: 'mhs-1', label: 'Masuk sebagai Mahasiswa', keterangan: 'Aulia Rahmawati - 2502019876' },
  { id: 'dsn-1', label: 'Masuk sebagai Dosen', keterangan: 'Pandu Wicaksono, S.Kom., M.Kom.' },
  { id: 'adm-1', label: 'Masuk sebagai Admin Prodi', keterangan: 'Yulia Hartanti' },
]

export type StatusLomba = 'terdaftar' | 'berlangsung' | 'selesai'
export type CapaianLomba = 'juara_1' | 'juara_2' | 'juara_3' | 'harapan' | 'finalis' | 'peserta' | null

export interface Anggota {
  id: string
  nama: string
  nim: string
  peran: string
}

export interface Berkas {
  id: string
  jenis: string
  nama: string
  ukuran: string
}

export interface Tahapan {
  id: string
  label: string
  tanggal: string
  selesai: boolean
}

export interface Lomba {
  id: string
  mahasiswaId: string
  nama: string
  penyelenggara: string
  bidang: string
  tingkat: string
  jenis: 'tim' | 'individu'
  status: StatusLomba
  capaian: CapaianLomba
  tanggalMulai: string
  tanggalSelesai: string
  deskripsi: string
  anggota: Anggota[]
  berkas: Berkas[]
  tahapan: Tahapan[]
  dosenId: string
}

const today = new Date()
const d = (offset: number) => {
  const dt = new Date(today)
  dt.setDate(dt.getDate() + offset)
  return dt.toISOString().split('T')[0]
}

export const DATA_LOMBA: Lomba[] = [
  {
    id: 'lmb-1', mahasiswaId: 'mhs-1',
    nama: 'Gemastik XVII 2024', penyelenggara: 'Kemendikbudristek', bidang: 'Pemrograman', tingkat: 'Nasional', jenis: 'tim',
    status: 'berlangsung', capaian: null,
    tanggalMulai: d(-60), tanggalSelesai: d(30),
    deskripsi: 'Kompetisi teknologi informasi mahasiswa tingkat nasional yang diselenggarakan oleh Kemendikbudristek.',
    anggota: [
      { id: 'a1', nama: 'Aulia Rahmawati', nim: '2502019876', peran: 'Ketua' },
      { id: 'a2', nama: 'Bagas Prayoga', nim: '2502011234', peran: 'Anggota' },
      { id: 'a3', nama: 'Citra Maheswari', nim: '2502015678', peran: 'Anggota' },
    ],
    berkas: [
      { id: 'b1', jenis: 'Bukti Pendaftaran', nama: 'bukti-daftar.pdf', ukuran: '234 KB' },
      { id: 'b2', jenis: 'Poster', nama: 'poster-gemastik.png', ukuran: '1.2 MB' },
    ],
    tahapan: [
      { id: 't1', label: 'Pendaftaran', tanggal: d(-60), selesai: true },
      { id: 't2', label: 'Technical Meeting', tanggal: d(-45), selesai: true },
      { id: 't3', label: 'Penyisihan', tanggal: d(-20), selesai: true },
      { id: 't4', label: 'Final', tanggal: d(10), selesai: false },
      { id: 't5', label: 'Pengumuman', tanggal: d(30), selesai: false },
    ],
    dosenId: 'dsn-1',
  },
  {
    id: 'lmb-2', mahasiswaId: 'mhs-1',
    nama: 'ICPC Asia Regional 2024', penyelenggara: 'ACM', bidang: 'Algoritma', tingkat: 'Internasional', jenis: 'tim',
    status: 'terdaftar', capaian: null,
    tanggalMulai: d(15), tanggalSelesai: d(80),
    deskripsi: 'International Collegiate Programming Contest regional Asia — ajang bergengsi untuk mahasiswa dalam pemecahan masalah algoritma.',
    anggota: [
      { id: 'a4', nama: 'Aulia Rahmawati', nim: '2502019876', peran: 'Ketua' },
      { id: 'a5', nama: 'Bagas Prayoga', nim: '2502011234', peran: 'Anggota' },
    ],
    berkas: [
      { id: 'b3', jenis: 'Bukti Pendaftaran', nama: 'registration-icpc.pdf', ukuran: '189 KB' },
    ],
    tahapan: [
      { id: 't6', label: 'Pendaftaran', tanggal: d(15), selesai: false },
      { id: 't7', label: 'Babak Penyisihan', tanggal: d(40), selesai: false },
      { id: 't8', label: 'Regional Final', tanggal: d(80), selesai: false },
    ],
    dosenId: 'dsn-1',
  },
  {
    id: 'lmb-3', mahasiswaId: 'mhs-1',
    nama: 'Hackathon Nasional Bank BNI', penyelenggara: 'Bank BNI', bidang: 'Inovasi Teknologi', tingkat: 'Nasional', jenis: 'tim',
    status: 'selesai', capaian: 'juara_2',
    tanggalMulai: d(-120), tanggalSelesai: d(-30),
    deskripsi: 'Hackathon 48 jam untuk menciptakan solusi inovatif di bidang perbankan digital.',
    anggota: [
      { id: 'a6', nama: 'Aulia Rahmawati', nim: '2502019876', peran: 'Ketua' },
      { id: 'a7', nama: 'Citra Maheswari', nim: '2502015678', peran: 'Anggota' },
    ],
    berkas: [
      { id: 'b4', jenis: 'Bukti Pendaftaran', nama: 'bukti-bni.pdf', ukuran: '210 KB' },
      { id: 'b5', jenis: 'Sertifikat', nama: 'sertifikat-juara2.pdf', ukuran: '450 KB' },
      { id: 'b6', jenis: 'Poster', nama: 'poster-bni.png', ukuran: '980 KB' },
    ],
    tahapan: [
      { id: 't9', label: 'Pendaftaran', tanggal: d(-120), selesai: true },
      { id: 't10', label: 'Seleksi Proposal', tanggal: d(-90), selesai: true },
      { id: 't11', label: 'Hackathon 48 Jam', tanggal: d(-45), selesai: true },
      { id: 't12', label: 'Pengumuman Pemenang', tanggal: d(-30), selesai: true },
    ],
    dosenId: 'dsn-2',
  },
  {
    id: 'lmb-4', mahasiswaId: 'mhs-1',
    nama: 'Kompetisi Desain UI/UX Tokopedia', penyelenggara: 'Tokopedia', bidang: 'Desain', tingkat: 'Nasional', jenis: 'individu',
    status: 'selesai', capaian: 'peserta',
    tanggalMulai: d(-150), tanggalSelesai: d(-70),
    deskripsi: 'Kompetisi desain antarmuka dan pengalaman pengguna untuk platform e-commerce terkemuka.',
    anggota: [
      { id: 'a8', nama: 'Aulia Rahmawati', nim: '2502019876', peran: 'Peserta' },
    ],
    berkas: [
      { id: 'b7', jenis: 'Bukti Pendaftaran', nama: 'registrasi-tokped.pdf', ukuran: '156 KB' },
    ],
    tahapan: [
      { id: 't13', label: 'Pendaftaran', tanggal: d(-150), selesai: true },
      { id: 't14', label: 'Pengumpulan Karya', tanggal: d(-110), selesai: true },
      { id: 't15', label: 'Pengumuman', tanggal: d(-70), selesai: true },
    ],
    dosenId: 'dsn-1',
  },
  {
    id: 'lmb-5', mahasiswaId: 'mhs-1',
    nama: 'Data Science Challenge ITB', penyelenggara: 'Institut Teknologi Bandung', bidang: 'Data Science', tingkat: 'Nasional', jenis: 'tim',
    status: 'terdaftar', capaian: null,
    tanggalMulai: d(5), tanggalSelesai: d(60),
    deskripsi: 'Kompetisi ilmu data tingkat nasional yang diselenggarakan oleh ITB dengan tema keberlanjutan.',
    anggota: [
      { id: 'a9', nama: 'Aulia Rahmawati', nim: '2502019876', peran: 'Ketua' },
      { id: 'a10', nama: 'Bagas Prayoga', nim: '2502011234', peran: 'Anggota' },
    ],
    berkas: [],
    tahapan: [
      { id: 't16', label: 'Pendaftaran', tanggal: d(5), selesai: false },
      { id: 't17', label: 'Submit Dataset', tanggal: d(30), selesai: false },
      { id: 't18', label: 'Final Presentation', tanggal: d(60), selesai: false },
    ],
    dosenId: 'dsn-1',
  },
  {
    id: 'lmb-6', mahasiswaId: 'mhs-2',
    nama: 'Business Plan Competition UGM', penyelenggara: 'Universitas Gadjah Mada', bidang: 'Bisnis', tingkat: 'Nasional', jenis: 'tim',
    status: 'berlangsung', capaian: null,
    tanggalMulai: d(-30), tanggalSelesai: d(45),
    deskripsi: 'Kompetisi rencana bisnis tingkat nasional yang menantang mahasiswa mengembangkan ide bisnis inovatif.',
    anggota: [
      { id: 'a11', nama: 'Bagas Prayoga', nim: '2502011234', peran: 'Ketua' },
    ],
    berkas: [
      { id: 'b8', jenis: 'Proposal', nama: 'proposal-bisplan.pdf', ukuran: '890 KB' },
    ],
    tahapan: [
      { id: 't19', label: 'Pendaftaran', tanggal: d(-30), selesai: true },
      { id: 't20', label: 'Seleksi Proposal', tanggal: d(10), selesai: false },
      { id: 't21', label: 'Final', tanggal: d(45), selesai: false },
    ],
    dosenId: 'dsn-2',
  },
  {
    id: 'lmb-7', mahasiswaId: 'mhs-3',
    nama: 'National Design Award 2024', penyelenggara: 'Asosiasi Desainer Grafis Indonesia', bidang: 'Desain', tingkat: 'Nasional', jenis: 'individu',
    status: 'selesai', capaian: 'juara_1',
    tanggalMulai: d(-200), tanggalSelesai: d(-90),
    deskripsi: 'Penghargaan desain nasional bergengsi untuk karya-karya terbaik mahasiswa DKV di Indonesia.',
    anggota: [
      { id: 'a12', nama: 'Citra Maheswari', nim: '2502015678', peran: 'Peserta' },
    ],
    berkas: [
      { id: 'b9', jenis: 'Sertifikat', nama: 'sertifikat-nda.pdf', ukuran: '560 KB' },
      { id: 'b10', jenis: 'Poster', nama: 'karya-terbaik.png', ukuran: '2.1 MB' },
    ],
    tahapan: [
      { id: 't22', label: 'Pendaftaran', tanggal: d(-200), selesai: true },
      { id: 't23', label: 'Kurasi Karya', tanggal: d(-150), selesai: true },
      { id: 't24', label: 'Pameran', tanggal: d(-100), selesai: true },
      { id: 't25', label: 'Pengumuman', tanggal: d(-90), selesai: true },
    ],
    dosenId: 'dsn-1',
  },
]

export function getLombaByMahasiswa(mahasiswaId: string) {
  return DATA_LOMBA.filter(l => l.mahasiswaId === mahasiswaId)
}

export function getLombaById(id: string) {
  return DATA_LOMBA.find(l => l.id === id)
}

export function getPenggunaById(id: string) {
  return SEMUA_PENGGUNA.find(p => p.id === id) ?? null
}

export function namaPengguna(id: string) {
  return getPenggunaById(id)?.nama ?? '-'
}

export const CAPAIAN_LABELS: Record<string, string> = {
  juara_1: 'Juara 1', juara_2: 'Juara 2', juara_3: 'Juara 3',
  harapan: 'Juara Harapan', finalis: 'Finalis', peserta: 'Peserta',
}

export const STATUS_LABELS: Record<string, string> = {
  terdaftar: 'Terdaftar', berlangsung: 'Berlangsung', selesai: 'Selesai',
}
