import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth, berandaRole } from './auth/AuthContext'
import AppShell from './components/layout/AppShell'
import Login from './pages/Login'
import Register from './pages/Register'
import DashboardMahasiswa from './pages/mahasiswa/DashboardMahasiswa'
import LombaSaya from './pages/mahasiswa/LombaSaya'
import PendaftaranLomba from './pages/mahasiswa/PendaftaranLomba'
import DetailLombaSaya from './pages/mahasiswa/DetailLombaSaya'
import Profil from './pages/mahasiswa/Profil'
import DashboardMonitoring from './pages/dosen/DashboardMonitoring'
import MonitoringLomba from './pages/dosen/MonitoringLomba'
import DetailLombaDosen from './pages/dosen/DetailLombaDosen'
import KalenderAgenda from './pages/dosen/KalenderAgenda'
import ArsipPrestasi from './pages/dosen/ArsipPrestasi'

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { sudahMasuk } = useAuth()
  if (!sudahMasuk) return <Navigate to="/login" replace />
  return <>{children}</>
}

function RequireRole({ roles, children }: { roles: string[]; children: React.ReactNode }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  if (!roles.includes(user.role)) return <Navigate to={berandaRole(user.role)} replace />
  return <>{children}</>
}

function AppRoutes() {
  const { sudahMasuk, beranda } = useAuth()

  return (
    <Routes>
      <Route path="/login" element={sudahMasuk ? <Navigate to={beranda} replace /> : <Login />} />

      <Route path="/daftar" element={sudahMasuk ? <Navigate to={beranda} replace /> : <Register />} />

      <Route element={
        <RequireAuth>
          <AppShell />
        </RequireAuth>
      }>
        {/* Mahasiswa routes */}
        <Route path="/" element={
          <RequireRole roles={['mahasiswa']}>
            <DashboardMahasiswa />
          </RequireRole>
        } />
        <Route path="/lomba-saya" element={
          <RequireRole roles={['mahasiswa']}>
            <LombaSaya />
          </RequireRole>
        } />
        <Route path="/lomba-saya/baru" element={
          <RequireRole roles={['mahasiswa']}>
            <PendaftaranLomba />
          </RequireRole>
        } />
        <Route path="/lomba-saya/:id" element={
          <RequireRole roles={['mahasiswa']}>
            <DetailLombaSaya />
          </RequireRole>
        } />

        {/* Dosen/Admin routes */}
        <Route path="/monitoring" element={
          <RequireRole roles={['dosen', 'admin']}>
            <DashboardMonitoring />
          </RequireRole>
        } />
        <Route path="/monitoring/lomba" element={
          <RequireRole roles={['dosen', 'admin']}>
            <MonitoringLomba />
          </RequireRole>
        } />
        <Route path="/monitoring/lomba/:id" element={
          <RequireRole roles={['dosen', 'admin']}>
            <DetailLombaDosen />
          </RequireRole>
        } />
        <Route path="/monitoring/kalender" element={
          <RequireRole roles={['dosen', 'admin']}>
            <KalenderAgenda />
          </RequireRole>
        } />
        <Route path="/monitoring/arsip" element={
          <RequireRole roles={['dosen', 'admin']}>
            <ArsipPrestasi />
          </RequireRole>
        } />

        {/* Shared */}
        <Route path="/profil" element={<Profil />} />
        <Route path="*" element={<Navigate to={beranda} replace />} />
      </Route>
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  )
}
